'use strict';

describe('myApp.xmlLoader module', function() {

  beforeEach(module('myApp.xmlLoader'));

  describe('xmlLoader controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var xmlCtrl = $controller('XMLCtrl');
      expect(xmlCtrl).toBeDefined();
    }));

  });
});