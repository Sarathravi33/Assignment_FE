
			$http.get("records.xml").then(function (response) {
				var dom;
				if (typeof DOMParser != "undefined") {
					var parser = new DOMParser();
					dom = parser.parseFromString(response.data, "text/xml");
				}
				else {
					var doc = new ActiveXObject("Microsoft.XMLDOM");
					doc.async = false;
					dom = doc.loadXML(response.data);
				}
				// Now response is a DOMDocument with childNodes etc.
				return dom;
			});