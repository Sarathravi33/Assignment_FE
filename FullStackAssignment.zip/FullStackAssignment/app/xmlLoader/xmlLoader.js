'use strict';

angular.module('myApp.xmlLoader', ['ngRoute','ngFileUpload'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/xmlLoader', {
    templateUrl: 'xmlLoader/xmlLoader.html',
    controller: 'XMLCtrl'
  });
}])

.controller('XMLCtrl', ['$scope','$http', function($scope,$http,$window) {
			
			$scope.SelectFile = function (file) {
                $scope.SelectedFile = file;
            };
            $scope.Upload = function () {
                var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.xml)$/;
                if (regex.test($scope.SelectedFile.name.toLowerCase())) {
                    if (typeof (FileReader) != "undefined") {
                        var reader = new FileReader();
                        //For Browsers other than IE.
                        if (reader.readAsBinaryString) {
                            reader.onload = function (e) {
                                $scope.ProcessXML(e.target.result);
                            };
                            reader.readAsBinaryString($scope.SelectedFile);
                        } else {
                            //For IE Browser.
                            reader.onload = function (e) {
                                var data = "";
                                var bytes = new Uint8Array(e.target.result);
                                for (var i = 0; i < bytes.byteLength; i++) {
                                    data += String.fromCharCode(bytes[i]);
                                }
                                $scope.ProcessXML(data);
                            };
                            reader.readAsArrayBuffer($scope.SelectedFile);
                        }
                    } else {
                        alert("This browser does not support HTML5.");
                    }
                } else {
                    alert("Please upload a valid XML file.");
                }
            };
			
			var x2js = new X2JS();
			function convertXml2JSon(data) {
				var jsonContentOfXml = JSON.stringify(x2js.xml_str2json(data));
				return jsonContentOfXml;
			}
		
			$scope.ProcessXML = function (data) {
               
			    var jsonContentOfXml = convertXml2JSon(data);
				// Parse the JSON String 
				var parsedJSON = JSON.parse(jsonContentOfXml);
				
				var xmlKeys = [];
				for(var kk in parsedJSON.records.record[0]) xmlKeys.push(kk);
   
                //Display the data from Excel file in Table.
                $scope.$apply(function () {
                    $scope.rowDatas = parsedJSON['records'].record;
					$scope.headers = xmlKeys;
                    $scope.IsVisible = true;
                });
				
				// To Sort and Filter data in the Screen
				$scope.reverseSort = false;
				$scope.columns = 'Issue count';
				$scope.sortData = function (col){
					$scope.reverseSort = ($scope.columns == col) ? !$scope.reverseSort : false;
					$scope.columns = col;
					}
            };
}]);