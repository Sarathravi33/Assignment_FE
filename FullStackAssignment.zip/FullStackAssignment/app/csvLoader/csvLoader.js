'use strict';

angular.module('myApp.csvLoader', ['ngRoute','ngFileUpload'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/csvLoader', {
    templateUrl: 'csvLoader/csvLoader.html',
    controller: 'CSVCtrl'
  });
}])

.controller('CSVCtrl', ['$scope','$http', function($scope,$http,$window) {
	
	$scope.SelectFile = function (file) {
                $scope.SelectedFile = file;
            };
            $scope.Upload = function () {
                var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.xls|.xlsx|.csv)$/;
                if (regex.test($scope.SelectedFile.name.toLowerCase())) {
                    if (typeof (FileReader) != "undefined") {
                        var reader = new FileReader();
                        //For Browsers other than IE.
                        if (reader.readAsBinaryString) {
                            reader.onload = function (e) {
                                $scope.ProcessExcel(e.target.result);
                            };
                            reader.readAsBinaryString($scope.SelectedFile);
                        } else {
                            //For IE Browser.
                            reader.onload = function (e) {
                                var data = "";
                                var bytes = new Uint8Array(e.target.result);
                                for (var i = 0; i < bytes.byteLength; i++) {
                                    data += String.fromCharCode(bytes[i]);
                                }
                                $scope.ProcessExcel(data);
                            };
                            reader.readAsArrayBuffer($scope.SelectedFile);
                        }
                    } else {
                        alert("This browser does not support HTML5.");
                    }
                } else {
                    alert("Please upload a valid Excel file.");
                }
            };
			
			$scope.ProcessExcel = function (data) {
                //Read the Excel File data.
                var workbook = XLSX.read(data, {
                    type: 'binary'
                });

                //Fetch the name of First Sheet.
                var firstSheet = workbook.SheetNames[0];

                //Read all rows from First Sheet into an JSON array.
                var excelRows = XLSX.utils.sheet_to_row_object_array(workbook.Sheets[firstSheet]);

				
				var keys = [];
				for(var k in excelRows[0]) keys.push(k);
    
   
                //Display the data from Excel file in Table.
                $scope.$apply(function () {
                    $scope.rowDatas = excelRows;
					$scope.headers = keys;
                    $scope.IsVisible = true;
					
                });
				
				// To Sort and Filter data in the Screen
				$scope.reverseSort = false;
				$scope.columns = 'Issue count';
				$scope.sortData = function (col){
					$scope.reverseSort = ($scope.columns == col) ? !$scope.reverseSort : false;
					$scope.columns = col;
					}
            };

}]);