'use strict';

describe('myApp.csvLoader module', function() {

  beforeEach(module('myApp.csvLoader'));

  describe('csvLoader controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var csvCtrl = $controller('CSVCtrl');
      expect(csvCtrl).toBeDefined();
    }));

  });
});